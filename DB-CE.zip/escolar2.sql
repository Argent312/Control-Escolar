-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 19, 2021 at 09:42 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `escolar2`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumnos`
--

CREATE TABLE `alumnos` (
  `idAlumno` int(11) NOT NULL,
  `curp` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidoPaterno` varchar(45) NOT NULL,
  `apellidoMaterno` varchar(45) NOT NULL,
  `edad` int(11) NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `tipoSangre` char(2) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `colonia` varchar(45) NOT NULL,
  `codigoPostal` varchar(45) NOT NULL,
  `entidad` varchar(45) NOT NULL,
  `nacionalidad` varchar(45) NOT NULL,
  `estadoAlumno` varchar(45) NOT NULL,
  `tecnologia` varchar(45) NOT NULL,
  `telEmergencia` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `alumns`
--

CREATE TABLE `alumns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoM` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `curp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edad` int(11) NOT NULL,
  `sexo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sangre` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `lugarNacimiento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nacionalidad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grado` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grupo` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `turno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colonia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entidad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ciudad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tutor_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asignaciongrupo`
--

CREATE TABLE `asignaciongrupo` (
  `idAsignacionGrupo` int(11) NOT NULL,
  `grupo` char(1) NOT NULL,
  `grado` char(1) NOT NULL,
  `alumnos_idAlumno` int(11) NOT NULL,
  `periodo_idPeriodo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `asignacionmateria`
--

CREATE TABLE `asignacionmateria` (
  `idAsignacionMateria` int(11) NOT NULL,
  `grado` char(1) NOT NULL,
  `grupo` char(1) NOT NULL,
  `turno` varchar(15) NOT NULL,
  `alumnos_idAlumno` int(11) NOT NULL,
  `maestros_idMaestros` int(11) NOT NULL,
  `tecnologia_idTecnologia` int(11) NOT NULL,
  `materias_idMaterias` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `calificaciones`
--

CREATE TABLE `calificaciones` (
  `idCalificaciones` int(11) NOT NULL,
  `calificacion` float NOT NULL,
  `faltas_asistencia` int(11) NOT NULL,
  `asistencias` varchar(45) NOT NULL,
  `grado` char(1) NOT NULL,
  `grupo` char(1) NOT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `alumnos_idAlumno` int(11) NOT NULL,
  `materias_idMaterias` int(11) NOT NULL,
  `Trimestre_idTrimestre` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cuentamaestro`
--

CREATE TABLE `cuentamaestro` (
  `idCuentaMaestro` int(11) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `maestros_idMaestros` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cuentasadministrativo`
--

CREATE TABLE `cuentasadministrativo` (
  `idCuentasAdministrativo` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidoPaterno` varchar(45) NOT NULL,
  `apellidoMaterno` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `turno` varchar(45) NOT NULL,
  `tipo` varchar(45) NOT NULL,
  `grado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cuentatutor`
--

CREATE TABLE `cuentatutor` (
  `idCuentaTutor` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidoPaterno` varchar(45) NOT NULL,
  `apellidoMaterno` varchar(45) NOT NULL,
  `ocupacion` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `ciudad` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `alumnos_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `maestros`
--

CREATE TABLE `maestros` (
  `idMaestros` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidoPaterno` varchar(45) NOT NULL,
  `apellidoMaterno` varchar(45) NOT NULL,
  `rfc` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `colonia` varchar(45) NOT NULL,
  `codioPostal` varchar(45) NOT NULL,
  `tel` varchar(45) NOT NULL,
  `cel` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `estado` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maestros`
--

INSERT INTO `maestros` (`idMaestros`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `rfc`, `direccion`, `colonia`, `codioPostal`, `tel`, `cel`, `email`, `estado`) VALUES
(1, 'Jose carlos', 'Enriquez', 'Hernandez', '4834929281', 'los sauces', 'Los prados', '91212', '55228456', '2281965220', 'jose@hotmail.com', 'Soltero'),
(2, 'MANUEL', 'OLGUIN', 'MEDINA', '54654651651', 'VITALICO SOLVA', '6 DE JUNIO', '91224', '554812', '255852155', 'OLGUIN@HOTMAIL.COM', 'SOLTERO'),
(3, 'MONSERRAT', 'LOPEZ', 'SANCHEZ', '54684156', 'VITALICO', 'HOMEX', '91254', '51164', '5649845151', 'MONSE@HOTMAIL.COM', 'CASADA');

-- --------------------------------------------------------

--
-- Table structure for table `materias`
--

CREATE TABLE `materias` (
  `idMaterias` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `clave` varchar(45) NOT NULL,
  `horaInicio` time NOT NULL,
  `horaFinalizaion` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `materias`
--

INSERT INTO `materias` (`idMaterias`, `nombre`, `clave`, `horaInicio`, `horaFinalizaion`) VALUES
(1, 'Español', '01', '19:08:19', '19:08:20'),
(2, 'Matematicas', '02', '19:16:50', '19:16:51'),
(3, 'Lengua extranjera', '03', '19:16:52', '19:16:53'),
(4, 'Ciencias', '04', '19:16:49', '19:16:49'),
(5, 'Historia', '05', '19:16:49', '19:16:49'),
(6, 'Geografia', '06', '19:16:49', '19:16:49'),
(7, 'Formacion civica y etica', '07', '19:16:49', '19:16:49'),
(8, 'Tecnologias', '08', '19:16:49', '19:16:49'),
(11, 'Educacion fisica', '09', '19:16:49', '19:16:49'),
(12, 'Artes', '10', '19:16:49', '19:16:49');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2019_08_19_000000_create_failed_jobs_table', 1),
(10, '2021_01_13_154514_create_tutors_table', 1),
(11, '2021_01_13_171738_create_alumns_table', 1),
(12, '2021_01_19_151923_create_schools_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `periodo`
--

CREATE TABLE `periodo` (
  `idPeriodo` int(11) NOT NULL,
  `inicioClase` date NOT NULL,
  `finClase` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `periodo`
--

INSERT INTO `periodo` (`idPeriodo`, `inicioClase`, `finClase`) VALUES
(1, '2021-01-05', '2021-01-07'),
(2, '2021-01-12', '2021-01-15'),
(3, '2021-01-18', '2021-01-28');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `director` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `municipio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ciudad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `control` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tecnologia`
--

CREATE TABLE `tecnologia` (
  `idTecnologia` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `clave` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tecnologia`
--

INSERT INTO `tecnologia` (`idTecnologia`, `nombre`, `clave`) VALUES
(1, 'Diseño Gráfico', '5011'),
(2, 'Informática Técnica', '5021'),
(3, 'Comunidades virtuales', '5031'),
(4, 'Procesos informáticos', '5043');

-- --------------------------------------------------------

--
-- Table structure for table `trimestre`
--

CREATE TABLE `trimestre` (
  `idTrimestre` int(11) NOT NULL,
  `numeroTimestre` varchar(45) NOT NULL,
  `periodo_idPeriodo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trimestre`
--

INSERT INTO `trimestre` (`idTrimestre`, `numeroTimestre`, `periodo_idPeriodo`) VALUES
(8, '1', 1),
(9, '2', 2),
(10, '3', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tutors`
--

CREATE TABLE `tutors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoP` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidoM` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domicilio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ciudad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colonia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ocupacion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telCasa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telTrabajo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tutors`
--

INSERT INTO `tutors` (`id`, `nombre`, `apellidoP`, `apellidoM`, `domicilio`, `ciudad`, `colonia`, `ocupacion`, `telCasa`, `telTrabajo`, `celular`, `created_at`, `updated_at`) VALUES
(1, 'Rene', 'Masa', 'Campos', 'Venustiano Carranza #65', 'Xalapa', 'La reverva', 'Administrador', '6876875', '6876875', '1234567', '2021-02-18 22:17:59', '2021-02-18 22:17:59'),
(2, 'Mario', 'Sanchez', 'Cordero', 'Matamoros #66', 'Xalapa', 'Altiplan', 'Policia', '+520448134159', '6876875', '1234567', '2021-02-18 22:25:29', '2021-02-18 22:25:29'),
(3, 'Mario', 'Sanchez', 'Cordero', 'Matamoros #66', 'Xalapa', 'Altiplan', 'Policia', '+520448134159', '6876875', '1234567', '2021-02-18 22:26:54', '2021-02-18 22:26:54'),
(4, 'Mario', 'Sanchez', 'Cordero', 'Matamoros #66', 'Xalapa', 'Altiplan', 'Policia', '+520448134159', '6876875', '1234567', '2021-02-18 22:30:12', '2021-02-18 22:30:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `tipo`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'prueba', 'prueba@gmail.com', NULL, '$2y$10$ogMswfh.J.YO.kVWVX9XBuuXwV2tt3f6X.txsdALoz8LaMDNuPJq6', 'subdirector', NULL, '2021-02-18 21:12:08', '2021-02-18 21:12:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`idAlumno`),
  ADD UNIQUE KEY `idalumnos_UNIQUE` (`idAlumno`),
  ADD UNIQUE KEY `curp_UNIQUE` (`curp`);

--
-- Indexes for table `alumns`
--
ALTER TABLE `alumns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alumns_tutor_id_foreign` (`tutor_id`);

--
-- Indexes for table `asignaciongrupo`
--
ALTER TABLE `asignaciongrupo`
  ADD PRIMARY KEY (`idAsignacionGrupo`),
  ADD UNIQUE KEY `idAsignacionGrupo_UNIQUE` (`idAsignacionGrupo`),
  ADD KEY `fk_asignacionGrupo_alumnos1_idx` (`alumnos_idAlumno`),
  ADD KEY `fk_asignacionGrupo_periodo1_idx` (`periodo_idPeriodo`);

--
-- Indexes for table `asignacionmateria`
--
ALTER TABLE `asignacionmateria`
  ADD PRIMARY KEY (`idAsignacionMateria`),
  ADD UNIQUE KEY `idAsignacionMateria_UNIQUE` (`idAsignacionMateria`),
  ADD KEY `fk_asignacionMateria_alumnos_idx` (`alumnos_idAlumno`),
  ADD KEY `fk_asignacionMateria_maestros1_idx` (`maestros_idMaestros`),
  ADD KEY `fk_asignacionMateria_tecnologia1_idx` (`tecnologia_idTecnologia`),
  ADD KEY `fk_asignacionMateria_materias1_idx` (`materias_idMaterias`);

--
-- Indexes for table `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`idCalificaciones`),
  ADD UNIQUE KEY `idCalificaciones_UNIQUE` (`idCalificaciones`),
  ADD KEY `fk_calificaciones_alumnos1_idx` (`alumnos_idAlumno`),
  ADD KEY `fk_calificaciones_materias1_idx` (`materias_idMaterias`),
  ADD KEY `fk_calificaciones_Trimestre1_idx` (`Trimestre_idTrimestre`);

--
-- Indexes for table `cuentamaestro`
--
ALTER TABLE `cuentamaestro`
  ADD PRIMARY KEY (`idCuentaMaestro`),
  ADD UNIQUE KEY `idCuentaMaestro_UNIQUE` (`idCuentaMaestro`),
  ADD UNIQUE KEY `usuario_UNIQUE` (`usuario`),
  ADD UNIQUE KEY `contraseña_UNIQUE` (`contraseña`),
  ADD KEY `fk_cuentaMaestro_maestros1_idx` (`maestros_idMaestros`);

--
-- Indexes for table `cuentasadministrativo`
--
ALTER TABLE `cuentasadministrativo`
  ADD PRIMARY KEY (`idCuentasAdministrativo`),
  ADD UNIQUE KEY `idCuentasAdministrativo_UNIQUE` (`idCuentasAdministrativo`),
  ADD UNIQUE KEY `usuario_UNIQUE` (`usuario`),
  ADD UNIQUE KEY `contraseña_UNIQUE` (`contraseña`);

--
-- Indexes for table `cuentatutor`
--
ALTER TABLE `cuentatutor`
  ADD PRIMARY KEY (`idCuentaTutor`),
  ADD UNIQUE KEY `idCuentaTutor_UNIQUE` (`idCuentaTutor`),
  ADD UNIQUE KEY `usuario_UNIQUE` (`usuario`),
  ADD UNIQUE KEY `contraseña_UNIQUE` (`contraseña`),
  ADD KEY `fk_cuentaTutor_alumnos1_idx` (`alumnos_idAlumno`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maestros`
--
ALTER TABLE `maestros`
  ADD PRIMARY KEY (`idMaestros`),
  ADD UNIQUE KEY `idMaestros_UNIQUE` (`idMaestros`),
  ADD UNIQUE KEY `rfc_UNIQUE` (`rfc`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `cel_UNIQUE` (`cel`);

--
-- Indexes for table `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`idMaterias`),
  ADD UNIQUE KEY `idMaterias_UNIQUE` (`idMaterias`),
  ADD UNIQUE KEY `clave_UNIQUE` (`clave`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `periodo`
--
ALTER TABLE `periodo`
  ADD PRIMARY KEY (`idPeriodo`),
  ADD UNIQUE KEY `idPeriodo_UNIQUE` (`idPeriodo`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tecnologia`
--
ALTER TABLE `tecnologia`
  ADD PRIMARY KEY (`idTecnologia`),
  ADD UNIQUE KEY `idTecnologia_UNIQUE` (`idTecnologia`),
  ADD UNIQUE KEY `clave_UNIQUE` (`clave`);

--
-- Indexes for table `trimestre`
--
ALTER TABLE `trimestre`
  ADD PRIMARY KEY (`idTrimestre`),
  ADD UNIQUE KEY `idBimestre_UNIQUE` (`idTrimestre`),
  ADD KEY `fk_Trimestre_periodo1_idx` (`periodo_idPeriodo`);

--
-- Indexes for table `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `idAlumno` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `alumns`
--
ALTER TABLE `alumns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asignaciongrupo`
--
ALTER TABLE `asignaciongrupo`
  MODIFY `idAsignacionGrupo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `asignacionmateria`
--
ALTER TABLE `asignacionmateria`
  MODIFY `idAsignacionMateria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `idCalificaciones` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cuentamaestro`
--
ALTER TABLE `cuentamaestro`
  MODIFY `idCuentaMaestro` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cuentasadministrativo`
--
ALTER TABLE `cuentasadministrativo`
  MODIFY `idCuentasAdministrativo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cuentatutor`
--
ALTER TABLE `cuentatutor`
  MODIFY `idCuentaTutor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `maestros`
--
ALTER TABLE `maestros`
  MODIFY `idMaestros` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `materias`
--
ALTER TABLE `materias`
  MODIFY `idMaterias` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `periodo`
--
ALTER TABLE `periodo`
  MODIFY `idPeriodo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tecnologia`
--
ALTER TABLE `tecnologia`
  MODIFY `idTecnologia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trimestre`
--
ALTER TABLE `trimestre`
  MODIFY `idTrimestre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alumns`
--
ALTER TABLE `alumns`
  ADD CONSTRAINT `alumns_tutor_id_foreign` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`id`);

--
-- Constraints for table `asignaciongrupo`
--
ALTER TABLE `asignaciongrupo`
  ADD CONSTRAINT `fk_asignacionGrupo_alumnos1` FOREIGN KEY (`alumnos_idAlumno`) REFERENCES `alumnos` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asignacionGrupo_periodo1` FOREIGN KEY (`periodo_idPeriodo`) REFERENCES `periodo` (`idPeriodo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `asignacionmateria`
--
ALTER TABLE `asignacionmateria`
  ADD CONSTRAINT `fk_asignacionMateria_alumnos` FOREIGN KEY (`alumnos_idAlumno`) REFERENCES `alumnos` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asignacionMateria_maestros1` FOREIGN KEY (`maestros_idMaestros`) REFERENCES `maestros` (`idMaestros`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asignacionMateria_materias1` FOREIGN KEY (`materias_idMaterias`) REFERENCES `materias` (`idMaterias`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asignacionMateria_tecnologia1` FOREIGN KEY (`tecnologia_idTecnologia`) REFERENCES `tecnologia` (`idTecnologia`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `fk_calificaciones_Trimestre1` FOREIGN KEY (`Trimestre_idTrimestre`) REFERENCES `trimestre` (`idTrimestre`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_calificaciones_alumnos1` FOREIGN KEY (`alumnos_idAlumno`) REFERENCES `alumnos` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_calificaciones_materias1` FOREIGN KEY (`materias_idMaterias`) REFERENCES `materias` (`idMaterias`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cuentamaestro`
--
ALTER TABLE `cuentamaestro`
  ADD CONSTRAINT `fk_cuentaMaestro_maestros1` FOREIGN KEY (`maestros_idMaestros`) REFERENCES `maestros` (`idMaestros`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cuentatutor`
--
ALTER TABLE `cuentatutor`
  ADD CONSTRAINT `fk_cuentaTutor_alumnos1` FOREIGN KEY (`alumnos_idAlumno`) REFERENCES `alumnos` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `trimestre`
--
ALTER TABLE `trimestre`
  ADD CONSTRAINT `fk_Trimestre_periodo1` FOREIGN KEY (`periodo_idPeriodo`) REFERENCES `periodo` (`idPeriodo`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
